"""Minimal CLI for the fitness and nutrition insight engine."""

from __future__ import annotations

import argparse

from core import add_entry, generate_brief, generate_weekly_summary


def _add_command() -> None:
    print("Type your daily fitness/nutrition entry. Press Enter when done:")
    raw_text = input("> ").strip()
    entry = add_entry(raw_text)
    print(f"Saved entry for {entry['date']}.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Fitness + Nutrition Insight Engine")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("add", help="Add a daily free-form entry")
    subparsers.add_parser("brief", help="Print the latest Daily Advice Brief")
    subparsers.add_parser("weekly", help="Print the latest weekly summary")

    args = parser.parse_args()
    if args.command == "add":
        _add_command()
    elif args.command == "brief":
        print(generate_brief())
    elif args.command == "weekly":
        print(generate_weekly_summary())


if __name__ == "__main__":
    main()
